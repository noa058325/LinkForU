import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Recommend } from '../core/models/recommend.model';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-comment',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit, OnDestroy {
  recommends: Recommend[] = [];
  currentIndex = 0;
  likedIds: number[] = [];
  intervalId: any;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.http.get<Recommend[]>('https://localhost:7091/api/Recommend')
      .subscribe(data => {
        this.recommends = data;
        this.startCarousel();
      });
  }

  startCarousel() {
    this.intervalId = setInterval(() => {
      this.currentIndex = (this.currentIndex + 1) % this.recommends.length;
    }, 4000); // דפדוף אוטומטי כל 4 שניות
  }

  like(rec: Recommend) {
    if (this.likedIds.includes(rec.id)) {
      // אם כבר לייקנו - נעשה אנלייק
      this.http.post(`https://localhost:7091/api/Recommend/${rec.id}/unlike`, {})
        .subscribe(() => {
          rec.likesCount--;
          this.likedIds = this.likedIds.filter(id => id !== rec.id);
        });
    } else {
      // אם עדיין לא לייקנו - נעשה לייק
      this.http.post(`https://localhost:7091/api/Recommend/${rec.id}/like`, {})
        .subscribe(() => {
          rec.likesCount++;
          this.likedIds.push(rec.id);
        });
    }
  }
  

  next() {
    this.currentIndex = (this.currentIndex + 1) % this.recommends.length;
  }

  prev() {
    this.currentIndex =
      (this.currentIndex - 1 + this.recommends.length) % this.recommends.length;
  }

  ngOnDestroy(): void {
    clearInterval(this.intervalId);
  }
}
