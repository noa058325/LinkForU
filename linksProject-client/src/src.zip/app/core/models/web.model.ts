export interface Web {
    id: number;
    name: string;
    link: string;
    idCategory: number;
    imageUrl?: string; 
  }