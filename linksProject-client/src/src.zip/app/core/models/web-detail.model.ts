export interface WebDetail {
    id: number;
    name: string;
    link: string;
    imageUrl?: string;
    coupon?: string;
    categoryName: string;
  }
  