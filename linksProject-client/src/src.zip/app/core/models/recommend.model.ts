export interface Recommend {
    id: number;
    name: string;
    description: string;
    likesCount: number;
    idUser: number;
  }